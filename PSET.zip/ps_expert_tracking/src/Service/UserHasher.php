<?php

declare(strict_types=1);

namespace PsExpertTracking\Service;

class UserHasher
{
    /**
     * Gl�wna metoda haszujaca (E-mail, Imie, Nazwisko, Adres)
     */
    public function hashUserData(?string $data): ?string
    {
        if (empty($data)) {
            return null;
        }
        // 1. Convert to lowercase
        // 2. Remove leading/trailing whitespace
        // 3. SHA256
        return hash('sha256', trim(strtolower($data)));
    }

    /**
     * Specjalna normalizacja dla numer�w telefon�w (Format E.164)
     */
    public function hashPhone(?string $phone): ?string
    {
        if (empty($phone)) {
            return null;
        }

        // 1. Usun wszystko co nie jest cyfra (spacje, myslniki, nawiasy)
        $clean = preg_replace('/[^\d]/', '', $phone);

        // 2. Obsluga polskiego prefiksu (jesli brak)
        // Google wymaga formatu +48xxxxxxxxx
        // Jesli numer ma 9 cyfr (np. 600100200), dodajemy 48.
        if (strlen($clean) === 9) {
            $clean = '48' . $clean;
        }
        
        // Jesli numer zaczyna sie od 0 (niekt�re stare formaty), usuwamy je
        $clean = ltrim($clean, '0');

        // 3. Dodajemy znak + na poczatku (standard E.164 wymaga +CC...)
        // Jednak do hashowania Google zaleca czysty ciag cyfr z kodem kraju
        // Dokumentacja: "Must be in E.164 format" -> czyli +48123456789
        $formatted = '+' . $clean;

        return $this->hashUserData($formatted);
    }
}