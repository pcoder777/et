<?php

declare(strict_types=1);

namespace PsExpertTracking\Hook;

use PsExpertTracking\Service\SessionManager;
use Context;
use PrestaShopLogger;

class CartHook
{
    private $sessionManager;

    public function __construct(SessionManager $sessionManager)
    {
        $this->sessionManager = $sessionManager;
    }

    public function execute(): void
    {
        // BEZPIECZNIK: Try-Catch zapobiega blokowaniu koszyka przez bledy trackingu
        try {
            $context = Context::getContext();
            if ($context->cart && $context->cart->id) {
                $this->sessionManager->saveSession((int)$context->cart->id);
            }
        } catch (\Throwable $e) {
            // Jesli wystapi blad, logujemy go, ale NIE PRZERYWAMY dzialania sklepu
            // Dzieki temu front.js nadal otrzyma odpowiedz "200 OK" i wysle add_to_cart
            PrestaShopLogger::addLog(
                'PsExpertTracking Cart Error: ' . $e->getMessage(),
                3 // Severity: Error
            );
        }
    }
}