<?php

declare(strict_types=1);

if (!defined('_PS_VERSION_')) {
    exit;
}

// RĘCZNY AUTOLOADER
require_once __DIR__ . '/src/Service/UserHasher.php';
require_once __DIR__ . '/src/Service/GoogleClient.php';
require_once __DIR__ . '/src/Service/DataLayerGenerator.php';
require_once __DIR__ . '/src/Service/SessionManager.php';
require_once __DIR__ . '/src/Utils/OrderHelper.php';
require_once __DIR__ . '/src/Hook/FrontHook.php';
require_once __DIR__ . '/src/Hook/CartHook.php';
require_once __DIR__ . '/src/Hook/OrderStatusHook.php';

use PsExpertTracking\Hook\FrontHook;
use PsExpertTracking\Hook\CartHook;
use PsExpertTracking\Hook\OrderStatusHook;
use PsExpertTracking\Service\DataLayerGenerator;
use PsExpertTracking\Service\GoogleClient;
use PsExpertTracking\Service\UserHasher;
use PsExpertTracking\Service\SessionManager;
use PsExpertTracking\Utils\OrderHelper;

class Ps_Expert_Tracking extends Module
{
    public function __construct()
    {
        $this->name = 'ps_expert_tracking';
        $this->tab = 'analytics_stats';
        $this->version = '2.1.0'; // Bump version
        $this->author = 'Expert Dev';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = ['min' => '1.7.0', 'max' => _PS_VERSION_];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Expert Tracking: Session Persistence');
        $this->description = $this->l('Naprawia problem unassigned traffic poprzez zapisywanie sesji GA4 w bazie.');
    }

    public function install(): bool
    {
        return parent::install() &&
            $this->registerHook('displayHeader') &&
            $this->registerHook('displayOrderConfirmation') &&
            $this->registerHook('actionOrderStatusPostUpdate') &&
            $this->registerHook('actionCartSave') &&
            $this->installDb();
    }

    public function uninstall(): bool
    {
        return parent::uninstall();
    }

    public function installDb(): bool
    {
        $sql = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'expert_sessions` (
            `id_cart` INT(10) UNSIGNED NOT NULL,
            `ga_client_id` VARCHAR(255) DEFAULT NULL,
            `ga_session_id` VARCHAR(50) DEFAULT NULL,
            `gclid` VARCHAR(255) DEFAULT NULL,
            `user_agent` VARCHAR(255) DEFAULT NULL,
            `date_add` DATETIME NOT NULL,
            PRIMARY KEY (`id_cart`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

        return Db::getInstance()->execute($sql);
    }

    // --- HOOKI ---

    public function hookDisplayHeader(array $params)
    {
        // 1. Łapanie GCLID z URL do Ciasteczka
        if (Tools::getIsset('gclid')) {
            $this->context->cookie->expert_gclid = Tools::getValue('gclid');
            $this->context->cookie->write();
        }

        $hasher = new UserHasher();
        $generator = new DataLayerGenerator($hasher);
        $hook = new FrontHook($generator);
        return $hook->executeHeader($params, $this);
    }

    public function hookDisplayOrderConfirmation(array $params)
    {
        $hasher = new UserHasher();
        $generator = new DataLayerGenerator($hasher);
        $hook = new FrontHook($generator);
        return $hook->executeOrderConfirmation($params, $this);
    }

    public function hookActionCartSave(array $params)
    {
        $sessionManager = new SessionManager();
        $hook = new CartHook($sessionManager);
        $hook->execute();
    }

    public function hookActionOrderStatusPostUpdate(array $params)
    {
        $client = new GoogleClient(); 
        $hasher = new UserHasher();
        $helper = new OrderHelper();
        $sessionManager = new SessionManager();

        $hook = new OrderStatusHook($client, $hasher, $helper, $sessionManager);
        $hook->execute($params);
    }
}