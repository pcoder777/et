document.addEventListener('DOMContentLoaded', function() {
    var $ = window.jQuery;
    
    // Jeśli jQuery nie jest załadowane, czekamy chwilę
    if (typeof $ === 'undefined') {
        setTimeout(waitForJQuery, 500);
    } else {
        initExpertTracking($);
    }

    function waitForJQuery() {
        if (window.jQuery) {
            initExpertTracking(window.jQuery);
        } else {
            console.warn('PsExpert: jQuery not detected, retrying...');
            setTimeout(waitForJQuery, 500);
        }
    }

    function initExpertTracking($) {
        console.log('PsExpert: Ready via jQuery');

        // GLOBALNY NASŁUCH AJAX (To jest klucz do sukcesu)
        $(document).ajaxSuccess(function(event, xhr, settings) {
            // Sprawdzamy czy URL lub Data zapytania dotyczy dodawania do koszyka
            // Presta wysyła parametry: add=1, action=update, controller=cart
            var isAddToCart = false;
            
            if (settings.data && (
                (settings.data.indexOf('add=1') > -1 && settings.data.indexOf('controller=cart') > -1) ||
                (settings.data.indexOf('action=update') > -1 && settings.data.indexOf('add=1') > -1)
            )) {
                isAddToCart = true;
            }

            // Czasami parametry są w URL
            if (settings.url && settings.url.indexOf('add=1') > -1 && settings.url.indexOf('controller=cart') > -1) {
                isAddToCart = true;
            }

            if (isAddToCart) {
                console.log('PsExpert: jQuery Ajax AddToCart detected!');
                
                // Pobieramy dane produktu ze strony (bo jeszcze na niej jesteśmy)
                var productData = scrapeProductData();
                
                // Jeśli nie udało się pobrać z DOM, próbujemy z odpowiedzi serwera (jeśli JSON)
                if (!productData && xhr.responseJSON && xhr.responseJSON.product) {
                     var p = xhr.responseJSON.product;
                     productData = {
                        id: p.id_product || p.id,
                        name: p.name,
                        price: parseFloat(p.price_amount || p.price_wt || 0),
                        quantity: parseInt(p.cart_quantity || p.quantity_wanted || 1)
                     };
                }

                if (productData) {
                    pushAddToCart(productData);
                }
            }
        });
    }

    function pushAddToCart(product) {
        // Deduplikacja (zapobiega podwójnym wysyłkom w ciągu 1 sekundy)
        var now = new Date().getTime();
        if (window.lastAddEventTime && (now - window.lastAddEventTime < 1000)) {
            return;
        }
        window.lastAddEventTime = now;

        console.log('PsExpert: WYSYŁAM add_to_cart do GTM', product);
        
        window.dataLayer.push({ ecommerce: null });
        window.dataLayer.push({
            'event': 'add_to_cart',
            'ecommerce': {
                'currency': (typeof prestashop !== 'undefined' && prestashop.currency) ? prestashop.currency.iso_code : 'PLN',
                'value': (product.price * product.quantity).toFixed(2),
                'items': [{
                    'item_id': product.id,
                    'item_name': product.name,
                    'price': product.price,
                    'quantity': product.quantity
                }]
            }
        });
    }

    function scrapeProductData() {
        // Próba 1: Inputy na karcie produktu (Standard PrestaShop)
        var id = $('input[name="id_product"]').val();
        var qty = $('input[name="qty"]').val() || $('#quantity_wanted').val() || 1;
        var name = $('h1[itemprop="name"]').text();
        var priceContent = $('[itemprop="price"]').attr('content');
        
        // Próba 2: Modal (jeśli właśnie wyskoczył)
        if (!id) {
            var $modal = $('#blockcart-modal');
            if ($modal.length) {
                name = $modal.find('.product-name').text();
                // Cena w modalu jest często sformatowana "123,00 zł", trzeba czyścić
                var priceTxt = $modal.find('.product-price').text(); 
                priceContent = priceTxt.replace(/[^\d.,]/g, '').replace(',', '.');
                // ID w modalu często nie ma, więc to jest metoda awaryjna
            }
        }

        // Próba 3: Ukryte dane w formularzu dodawania (najpewniejsze)
        if (!id) {
            var $form = $('form[action*="controller=cart"]');
            id = $form.find('input[name="id_product"]').val();
        }

        if (id) {
            return {
                id: id,
                name: name ? name.trim() : 'Produkt',
                price: parseFloat(priceContent || 0),
                quantity: parseInt(qty)
            };
        }
        return null;
    }
});