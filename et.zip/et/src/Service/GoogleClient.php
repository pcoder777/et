<?php

declare(strict_types=1);

namespace PsExpertTracking\Service;

use Configuration;

class GoogleClient
{
    private $measurementId;
    private $apiSecret;
    private $logger;

    public function __construct($logger = null)
    {
        $this->logger = $logger;
        
        // --- DANE PRODUKCYJNE ---
        $this->measurementId = 'G-LM6KRYGMJ3';
        $this->apiSecret = 'G5BdndspT36KnbXee_Z1rg';
    }

    // ZMIANA: Dodano argument $gclid
    public function sendPurchaseEvent(array $payload, ?string $gclid = null): void
    {
        if (empty($this->measurementId) || empty($this->apiSecret)) {
            return;
        }

        $url = sprintf(
            'https://www.google-analytics.com/mp/collect?measurement_id=%s&api_secret=%s',
            $this->measurementId,
            $this->apiSecret
        );

        // ZMIANA: Jeśli mamy GCLID, doklejamy go do adresu URL (sugestia audytora)
        if ($gclid) {
            $url .= '&gclid=' . urlencode($gclid);
        }

        $ch = curl_init($url);
        $payloadJson = json_encode($payload);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payloadJson);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        
        curl_close($ch);

        if ($httpCode >= 200 && $httpCode < 300) {
            \PrestaShopLogger::addLog(
                'PsExpertTracking GA4 Success. Order ID: ' . ($payload['events'][0]['params']['transaction_id'] ?? 'Unknown') . 
                ($gclid ? ' [GCLID: TAK]' : ' [GCLID: BRAK]'), 
                1
            );
        } else {
            \PrestaShopLogger::addLog(
                'PsExpertTracking GA4 Error: ' . $error . ' Code: ' . $httpCode . ' Response: ' . $response, 
                3
            );
        }
    }
}