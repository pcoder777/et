<?php

declare(strict_types=1);

namespace PsExpertTracking\Service;

use Db;
use Context;

class SessionManager
{
    private $tableName;

    public function __construct()
    {
        $this->tableName = _DB_PREFIX_ . 'expert_sessions';
    }

    public function saveSession(int $cartId): void
    {
        if (!$cartId) return;

        $context = Context::getContext();
        $cookie = $context->cookie;

        // 1. Pobieramy GA Client ID
        $clientId = null;
        if (isset($_COOKIE['_ga'])) {
            // Format _ga to zazwyczaj GA1.2.123456.7890 -> pobieramy 123456.7890
            $parts = explode('.', $_COOKIE['_ga']);
            if (count($parts) >= 4) {
                $clientId = $parts[2] . '.' . $parts[3];
            }
        }

        // 2. Pobieramy GCLID (z ciasteczka PS, bo URL mógł się zmienić)
        $gclid = isset($cookie->expert_gclid) ? $cookie->expert_gclid : null;

        if (!$clientId && !$gclid) {
            return; // Nie ma co zapisywać
        }

        // 3. Zapisujemy do bazy (ON DUPLICATE KEY UPDATE)
        $userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? substr($_SERVER['HTTP_USER_AGENT'], 0, 250) : '';
        
        $sql = 'INSERT INTO `' . $this->tableName . '` (id_cart, ga_client_id, gclid, user_agent, date_add)
                VALUES (' . (int)$cartId . ', "' . pSQL($clientId) . '", "' . pSQL($gclid) . '", "' . pSQL($userAgent) . '", NOW())
                ON DUPLICATE KEY UPDATE 
                ga_client_id = VALUES(ga_client_id),
                gclid = VALUES(gclid),
                date_add = NOW()';

        Db::getInstance()->execute($sql);
    }

    public function getSessionData(int $cartId): ?array
    {
        $sql = 'SELECT * FROM `' . $this->tableName . '` WHERE id_cart = ' . (int)$cartId;
        $row = Db::getInstance()->getRow($sql);
        
        return $row ?: null;
    }
}