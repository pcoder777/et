<?php

declare(strict_types=1);

namespace PsExpertTracking\Hook;

use Configuration;
use Order;
use Customer;
use Address; // <--- WAŻNE: Musimy zaimportować klasę Address
use Country;
use PsExpertTracking\Service\GoogleClient;
use PsExpertTracking\Service\UserHasher;
use PsExpertTracking\Service\SessionManager;
use PsExpertTracking\Utils\OrderHelper;

class OrderStatusHook
{
    private $client;
    private $hasher;
    private $helper;
    private $sessionManager;

    public function __construct($client, $hasher, $helper, $sessionManager)
    {
        $this->client = $client;
        $this->hasher = $hasher;
        $this->helper = $helper;
        $this->sessionManager = $sessionManager;
    }

    public function execute(array $params): void
    {
        if (!isset($params['newOrderStatus'], $params['id_order'])) {
            return;
        }

        $newStatusId = (int)$params['newOrderStatus']->id;
        $orderId = (int)$params['id_order'];

        // Statusy sukcesu
        $allowedStatuses = [
            (int)Configuration::get('PS_OS_PAYMENT'), // 2
            12, // P24
            34, // P24
            35, // COD
            3,  // Processing
            21, // Shipped
            10, // Bank wire
        ];
        
        $isPaidStatus = $params['newOrderStatus']->paid == 1;

        if (!in_array($newStatusId, $allowedStatuses) && !$isPaidStatus) {
            return;
        }

        $order = new Order($orderId);
        if (!$this->helper->isValidOrder($order)) {
            return;
        }

        // Odzyskiwanie sesji (GCLID/_GA z bazy)
        $sessionData = $this->sessionManager->getSessionData((int)$order->id_cart);
        $clientId = $sessionData['ga_client_id'] ?? $this->helper->getClientIdForServerSide($order);
        $gclid = $sessionData['gclid'] ?? null;

        // --- POBIERANIE DANYCH UŻYTKOWNIKA (FULL ENHANCED CONVERSIONS) ---
        $customer = new Customer((int)$order->id_customer);
        
        // Pobieramy adres dostawy (lub faktury, jeśli wolisz)
        $addressId = (int)$order->id_address_delivery;
        $address = new Address($addressId);
        
        // Pobieramy kod kraju (ISO)
        $countryIso = '';
        if ($address->id_country) {
            $country = new Country((int)$address->id_country);
            $countryIso = $country->iso_code;
        }

        // Priorytet telefonu: Komórkowy -> Stacjonarny
        $phone = !empty($address->phone_mobile) ? $address->phone_mobile : $address->phone;

        // Budowanie sekcji user_data
        $userData = [
            'sha256_email_address' => [$this->hasher->hashUserData($customer->email)],
        ];

        // Dodajemy telefon (jeśli jest)
        if ($phone) {
            $hashedPhone = $this->hasher->hashPhone($phone);
            if ($hashedPhone) {
                $userData['sha256_phone_number'] = [$hashedPhone];
            }
        }

        // Dodajemy dane adresowe (Imię, Nazwisko, Ulica, Miasto, Kod, Kraj)
        $addressInfo = [];
        
        if (!empty($address->firstname)) $addressInfo['sha256_first_name'] = [$this->hasher->hashUserData($address->firstname)];
        if (!empty($address->lastname))  $addressInfo['sha256_last_name']  = [$this->hasher->hashUserData($address->lastname)];
        if (!empty($address->address1))  $addressInfo['sha256_street']     = [$this->hasher->hashUserData($address->address1)];
        if (!empty($address->city))      $addressInfo['sha256_city']       = [$this->hasher->hashUserData($address->city)];
        if (!empty($address->postcode))  $addressInfo['sha256_postal_code']= [$this->hasher->hashUserData($address->postcode)];
        if (!empty($countryIso))         $addressInfo['sha256_country']    = [$this->hasher->hashUserData($countryIso)];

        if (!empty($addressInfo)) {
            $userData['address_info'] = $addressInfo;
        }
        // -----------------------------------------------------------------

        $products = $order->getProducts();
        $items = [];

        foreach ($products as $p) {
            $items[] = [
                'item_id' => (string)$p['product_id'],
                'item_name' => $p['product_name'],
                'price' => (float)$p['product_price_wt'],
                'quantity' => (int)$p['product_quantity']
            ];
        }

        $payload = [
            'client_id' => $clientId,
            'user_id' => (string)$customer->id,
            'non_personalized_ads' => false,
            'events' => [
                [
                    'name' => 'purchase',
                    'params' => [
                        'transaction_id' => (string)$order->id,
                        'value' => (float)$order->total_paid,
                        'currency' => 'PLN',
                        'tax' => (float)($order->total_paid - $order->total_paid_tax_excl),
                        'shipping' => (float)$order->total_shipping,
                        'items' => $items,
                        'debug_mode' => 1,
                        // Dodajemy user_data też do params (dla pewności w niektórych konfiguracjach GTM SS)
                        'user_data' => $userData 
                    ]
                ]
            ],
            // Główne miejsce dla user_data w Measurement Protocol GA4
            'user_data' => $userData 
        ];

        $this->client->sendPurchaseEvent($payload, $gclid);
    }
}