<?php

declare(strict_types=1);

namespace PsExpertTracking\Service;

class UserHasher
{
    public function hashUserData(string $data): string
    {
        return hash('sha256', trim(strtolower($data)));
    }
}