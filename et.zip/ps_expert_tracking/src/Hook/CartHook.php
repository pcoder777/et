<?php

declare(strict_types=1);

namespace PsExpertTracking\Hook;

use PsExpertTracking\Service\SessionManager;
use Context;

class CartHook
{
    private $sessionManager;

    public function __construct(SessionManager $sessionManager)
    {
        $this->sessionManager = $sessionManager;
    }

    public function execute(): void
    {
        $context = Context::getContext();
        if ($context->cart && $context->cart->id) {
            $this->sessionManager->saveSession((int)$context->cart->id);
        }
    }
}