<?php

declare(strict_types=1);

namespace PsExpertTracking\Hook;

use Configuration;
use Order;
use Customer;
use PsExpertTracking\Service\GoogleClient;
use PsExpertTracking\Service\UserHasher;
use PsExpertTracking\Service\SessionManager;
use PsExpertTracking\Utils\OrderHelper;

class OrderStatusHook
{
    private $client;
    private $hasher;
    private $helper;
    private $sessionManager;

    public function __construct($client, $hasher, $helper, $sessionManager)
    {
        $this->client = $client;
        $this->hasher = $hasher;
        $this->helper = $helper;
        $this->sessionManager = $sessionManager;
    }

    public function execute(array $params): void
    {
        if (!isset($params['newOrderStatus'], $params['id_order'])) {
            return;
        }

        $newStatusId = (int)$params['newOrderStatus']->id;
        $orderId = (int)$params['id_order'];

        // Statusy sukcesu
        $allowedStatuses = [
            (int)Configuration::get('PS_OS_PAYMENT'), // 2
            12, // P24
            34, // P24
            35, // COD
            3,  // Processing
            21, // Shipped
            10, // Bank wire
        ];
        
        $isPaidStatus = $params['newOrderStatus']->paid == 1;

        if (!in_array($newStatusId, $allowedStatuses) && !$isPaidStatus) {
            return;
        }

        $order = new Order($orderId);
        if (!$this->helper->isValidOrder($order)) {
            return;
        }

        // --- ODZYSKIWANIE SESJI (KLUCZ DO SUKCESU) ---
        $sessionData = $this->sessionManager->getSessionData((int)$order->id_cart);
        
        // 1. Client ID (Pierwszeństwo ma baza, potem helper fallback)
        $clientId = $sessionData['ga_client_id'] ?? $this->helper->getClientIdForServerSide($order);
        
        // 2. GCLID (Dla Google Ads)
        $gclid = $sessionData['gclid'] ?? null;

        $customer = new Customer((int)$order->id_customer);
        $products = $order->getProducts();
        $items = [];

        foreach ($products as $p) {
            $items[] = [
                'item_id' => (string)$p['product_id'],
                'item_name' => $p['product_name'],
                'price' => (float)$p['product_price_wt'],
                'quantity' => (int)$p['product_quantity']
            ];
        }

        $payload = [
            'client_id' => $clientId,
            'user_id' => (string)$customer->id,
            'non_personalized_ads' => false,
            'events' => [
                [
                    'name' => 'purchase',
                    'params' => [
                        'transaction_id' => (string)$order->id,
                        'value' => (float)$order->total_paid,
                        'currency' => 'PLN',
                        'tax' => (float)($order->total_paid - $order->total_paid_tax_excl),
                        'shipping' => (float)$order->total_shipping,
                        'items' => $items,
                        'debug_mode' => 1
                    ]
                ]
            ],
            'user_data' => [
                'sha256_email_address' => $this->hasher->hashUserData($customer->email)
            ]
        ];

        // Jeśli odzyskaliśmy GCLID, dodajemy go do payloadu (dla Ads)
        // Uwaga: W Measurement Protocol GCLID dodaje się do URL lub params, ale
        // najbezpieczniej dodać go do params eventu jako 'gclid', choć oficjalnie MP woli user_data.
        // Jednak kluczowe jest to, że mamy poprawny client_id.
        if ($gclid) {
            // W niektórych konfiguracjach MP gclid jest przekazywany w URL, ale tutaj
            // polegamy na silnym linkowaniu przez client_id + email.
            // Można go dodać do params dla pewności:
            $payload['events'][0]['params']['gclid'] = $gclid;
        }

        $this->client->sendPurchaseEvent($payload);
    }
}